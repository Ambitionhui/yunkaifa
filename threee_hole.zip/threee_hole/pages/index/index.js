var app = getApp();
import {
  globalUrls
} from "../../utils/url.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;

    if (typeof this.getTabBar === 'function' &&
      this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0
      })
    }
    wx.request({
       url: globalUrls.get_all_message_url,
      //url:'http://127.0.0.1:80/home/threehole/message/get_all_message',
      method: "GET",
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success(res) {
        console.log(res.data);
        if (res.data.msg == "数据获取成功！") {
          var threehole = res.data.data;
          that.setData({
            threehole: threehole
          })
        } else {
          console.log(res.data.msg)
        }
      },
      fail(e){
        console.log(e)
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  total_likes: function (e) {
    var that = this;
    var message_id = e.currentTarget.dataset.message_id;
    var three_holeNum = e.currentTarget.dataset.three_holenum;
    var threehole = that.data.threehole;

    if (app.globalData.userInfo == "未登录") {
      wx.showModal({
        title: "点赞失败",
        content: "请登录后再点赞",
      }, 2000)
    } else {
      wx.request({
        url: globalUrls.do_like_url,
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded",
          "z-token":app.globalData.userToken
        },
        data: {
          message_id: message_id
        },
        success(res) {
          //console.log(res.data);
          if (res.data.code == 0) {
            var total_likes = parseInt(res.data.data.total_likes);
            threehole[three_holeNum].total_likes = total_likes
            that.setData({
              threehole: threehole
            })
          } else {
            //console.log(res.data.msg)
            wx.showModal({
              title: "点赞失败",
              content: res.data.msg,
            }, 2000)
          }
        }
      })
    }

  },
  write_three_hole: function () {
    if (app.globalData.userInfo == "未登录") {
      wx.showModal({
        title: "打开失败",
        content: "请登录后再打开",
      }, 2000)
    } else {
      wx.navigateTo({
        url: '../write/write',
      })
    }
  },
  reply:function(e){
    //console.log(e.currentTarget.dataset.messagenum);
    wx.navigateTo({
      url: '../reply/reply?messagenum='+e.currentTarget.dataset.messagenum,
    })
  }

})