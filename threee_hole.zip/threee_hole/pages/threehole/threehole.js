// pages/threehole/threehole.js
const app = getApp()
import {
  globalUrls
} from "../../utils/url.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
       
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (typeof this.getTabBar === 'function' &&
    this.getTabBar()) {
    this.getTabBar().setData({
      selected: 1
    })
    }
  
    if(app.globalData.userInfo == "未登录"){
      var user = {
        "username":"未登录",
        "face_url":"http://qd7elsjan.bkt.clouddn.com/l_dangxiao.png"
      }
      that.setData({
        user:user
      })
    }else{
      that.setData({
        user:app.globalData.userInfo
      })
      that.getMyThreeHole();
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getlogin: function(){
    wx.navigateTo({
      url: '../login/login',
    })
  },
  loginout:function(){
    wx.removeStorage({
      key: 'userToken',
    })
    app.globalData.userInfo = "未登录";
    this.setData({
      threehole:null
    })
    this.onShow();
  },
  getMyThreeHole:function(){
    var that = this;
    //console.log("userInfo",app.globalData.userInfo)
    wx.request({
      url: globalUrls.get_my_user_message_url,
      method: "GET",
      header: {
        "Content-Type": "application/x-www-form-urlencoded",
        "z-token":app.globalData.userToken
      },
      success(res) {
        //console.log(res.data);
        if (res.data.code == 0) {
          var threehole = res.data.data;
          that.setData({
            threehole:threehole
          })
        } else {
          console.log(res.data.msg)
          wx.showModal({
            title:res.data.msg,
            content:"请重新登录"
          })
        }
      }
    })
  },
  total_delect:function(e){
    var num = e.currentTarget.dataset.num;
    var threehole = this.data.threehole;
    var that = this;
    wx.request({
      url: globalUrls.delect_message_url,
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded",
        "z-token":app.globalData.userToken
      },
      data: {
        message_id:threehole[num].id
      },
      success(res) {
        console.log(res.data);
        if (res.data.code == 0) {
          threehole.splice(num,1);
          wx.showModal({
            title:"删除成功"
          })
          that.setData({
            threehole:threehole
          })
        } else {
          wx.showModal({
            title:"删除失败"
          })
        }
      }
    })
  }
})