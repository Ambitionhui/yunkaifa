var app = getApp();
import {
  globalUrls
} from "../../utils/url.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  formSubmit(e) {
    //console.log('form发生了submit事件，携带数据为：', e.detail.value)
    var zz = e.detail.value.zz;
    var mm = e.detail.value.mm;
    wx.request({
      url: globalUrls.login_url,
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      data: {
        phone: zz,
        password: mm
      },
      success(res) {
        console.log(res.data);
        if (res.data.code == 0) {
          //console.log("+")
          wx.showModal({
            title: res.data.msg,
            content: res.data.msg,
          }, 2000)
          app.globalData.userInfo = res.data.data;
          app.globalData.userToken = res.data.ztoken;
          wx.setStorage({
            data:  res.data.ztoken,
            key: 'userToken',
          })
          wx.navigateBack({
            delta: 0,
          })
        } else {
          wx.showModal({
            title: "登录失败",
            content: res.data.msg,
          }, 2000)
        }
      }
    })
  },
  tosign: function () {
    wx.navigateTo({
      url: '../sign/sign',
    })
  },

  formReset(e) {
    //console.log('form发生了reset事件，携带数据为：', e.detail.value)
    this.setData({
      chosen: ''
    })
  }
})