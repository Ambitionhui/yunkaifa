// pages/write/write.js
var app = getApp();
import {
    globalUrls
  } from "../../utils/url.js";
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    formReset(e) {
        //console.log('form发生了reset事件，携带数据为：', e.detail.value)
        this.setData({
          chosen: ''
        })
      },
    formSubmit(e){
        console.log(e.detail.value.connect);
        if(e.detail.value.connect != ""){
            console.log(app.globalData.userInfo)
            wx.request({
                url: globalUrls.publish_new_message_url,
                method: "POST",
                header: {
                  "Content-Type": "application/x-www-form-urlencoded",
                  "z-token":app.globalData.userToken
                },
                data: {
                    user_name:app.globalData.userInfo.username,
                    face_url:app.globalData.userInfo.face_url,
                    connect:e.detail.value.connect
                },
                success(res) {
                  console.log(res.data);
                  if (res.data.code == 0) {
                    wx.showModal({
                      title: res.data.msg,
                      content: res.data.msg,
                    }, 2000)
                    wx.navigateBack({
                      delta: 0,
                    })
                  } else {
                    wx.showModal({
                      title: "发布失败",
                      content: res.data.msg,
                    }, 2000)
                  }
                }
              })
        }else{
            wx.showModal({
              title:"请输入内容后再发布！"
            })
        }
    }
})