// pages/reply/reply.js
var app = getApp();
import {
  globalUrls
} from "../../utils/url.js";
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var that = this;
        var messagenum = parseInt(options.messagenum);
        var pages = getCurrentPages();
        var prevPage = pages[pages.length-2];
        var threehole = prevPage.data.threehole;
        //console.log("userInfo",app.globalData.userInfo)
        // wx.request({
        //     url: "http://2tuv5h.natappfree.cc/home/threehole/reply/publish_message_reply",
        //     method: "POST",
        //     header: {
        //       "Content-Type": "application/x-www-form-urlencoded",
        //       "z-token":app.globalData.userToken
        //     },
        //     data: {
        //         message_id: threehole[messagenum].id,
        //         userId_host:threehole[messagenum].user_id,
        //         connect:"收到",
        //         message_timestamp:threehole[messagenum].send_timestamp,
        //         userName_visiton:app.globalData.userInfo.username
        //     },
        //     success(res) {
        //       console.log(res.data);
        //       if (res.data.code == 0) {
        //         //console.log("+")
        //         wx.showModal({
        //           title: res.data.msg,
        //           content: res.data.msg,
        //         }, 2000)
        //       } else {
        //         wx.showModal({
        //           title: "登录失败",
        //           content: res.data.msg,
        //         }, 2000)
        //       }
        //     }
        //   })
        wx.request({
            url: globalUrls.get_message_reply,
            method: "POST",
            header: {
              "Content-Type": "application/x-www-form-urlencoded",
              "z-token":app.globalData.userToken
            },
            data: {
                 message_id: threehole[messagenum].id
            },
            success(res) {
              console.log(threehole[messagenum])
              console.log(res.data.data);
              that.setData({
                top:threehole[messagenum],
                reply:res.data.data
              })
              
            },
            fail(e){
              console.log(e)
            }
          })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})