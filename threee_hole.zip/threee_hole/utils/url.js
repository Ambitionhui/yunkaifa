const ym="http://v5zvmh.natappfree.cc"
const globalUrls = {
    sign_url:ym+"/home/user/sign",
    login_url:ym+"/home/user/login",
    get_userInfo_url:ym+"/home/user/get_userInfo",
    publish_new_message_url:ym+"/home/threehole/message/publish_noew_message",
    get_all_message_url:ym+"/home/threehole/message/get_all_message",
    get_my_user_message_url:ym+"/home/threehole/message/get_my_user_message",
    do_like_url:ym+"/home/threehole/message/do_like",
    delect_message_url:ym+"/home/threehole/message/delect_message",
    get_message_reply:ym+"/home/threehole/reply/get_message_reply"
  }
  export { 
    globalUrls
  }